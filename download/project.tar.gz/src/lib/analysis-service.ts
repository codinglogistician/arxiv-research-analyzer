import ZAI from 'z-ai-web-dev-sdk';
import type { ArxivSearchResult, ArticleAnalysis, ResearchAnalysis } from './types';

export class AnalysisService {
  private zai: Awaited<ReturnType<typeof ZAI.create>> | null = null;

  async initialize() {
    if (!this.zai) {
      this.zai = await ZAI.create();
    }
    return this.zai;
  }

  /**
   * Parse JSON from LLM response, handling markdown code blocks
   */
  private parseJsonFromResponse(response: string): any {
    // Try direct parse first
    try {
      return JSON.parse(response);
    } catch {
      // Continue to other methods
    }

    // Try extracting from markdown code blocks
    const jsonBlockMatch = response.match(/```(?:json)?\s*([\s\S]*?)```/);
    if (jsonBlockMatch) {
      try {
        return JSON.parse(jsonBlockMatch[1].trim());
      } catch {
        // Continue
      }
    }

    // Try finding JSON object in the response
    const jsonObjectMatch = response.match(/\{[\s\S]*\}/);
    if (jsonObjectMatch) {
      try {
        return JSON.parse(jsonObjectMatch[0]);
      } catch {
        // Continue
      }
    }

    return null;
  }

  /**
   * Analyze a single article based on the focus area
   */
  async analyzeArticle(
    article: ArxivSearchResult,
    focusArea: string
  ): Promise<ArticleAnalysis> {
    await this.initialize();

    const prompt = `Analyze the following academic article in the context of: "${focusArea}"

Article Title: ${article.title}
Authors: ${article.authors?.join?.(', ') || 'Unknown'}
Abstract: ${article.abstract || 'No abstract available'}

Please provide:
1. A relevance score (0-100) for how relevant this article is to the focus area
2. 3-5 key points from this article related to the focus area
3. Brief methodology description (if determinable)
4. Main findings (if determinable)

Respond ONLY with a valid JSON object in this exact format:
{
  "relevanceScore": 75,
  "keyPoints": ["point 1", "point 2", "point 3"],
  "methodology": "description",
  "findings": ["finding 1", "finding 2"]
}`;

    try {
      const completion = await this.zai!.chat.completions.create({
        messages: [
          {
            role: 'assistant',
            content: 'You are an expert academic research analyst. Provide thorough, accurate analysis of academic papers. Always respond with ONLY valid JSON, no markdown code blocks or additional text.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        thinking: { type: 'disabled' }
      });

      const response = completion.choices[0]?.message?.content || '{}';
      console.log('[AnalysisService] Article analysis response:', response.substring(0, 200));
      
      const parsed = this.parseJsonFromResponse(response);
      
      if (parsed) {
        return {
          articleId: article.id,
          relevanceScore: typeof parsed.relevanceScore === 'number' ? parsed.relevanceScore : 50,
          keyPoints: Array.isArray(parsed.keyPoints) ? parsed.keyPoints : ['Analysis not available'],
          methodology: typeof parsed.methodology === 'string' ? parsed.methodology : 'Not determined',
          findings: Array.isArray(parsed.findings) ? parsed.findings : []
        };
      }
    } catch (error) {
      console.error('[AnalysisService] Article analysis error:', error);
    }

    // Default response if parsing fails
    return {
      articleId: article.id,
      relevanceScore: 50,
      keyPoints: ['Analysis could not be generated'],
      methodology: 'Not determined',
      findings: []
    };
  }

  /**
   * Generate a comprehensive research analysis from multiple articles
   */
  async generateResearchAnalysis(
    articles: (ArxivSearchResult & { analysis?: ArticleAnalysis })[],
    topic: string,
    focusArea: string
  ): Promise<Omit<ResearchAnalysis, 'sessionId'>> {
    await this.initialize();

    // Prepare article summaries
    const articleSummaries = articles.map((a, i) => ({
      index: i + 1,
      title: a.title,
      authors: a.authors?.slice?.(0, 3)?.join?.(', ') + ((a.authors?.length || 0) > 3 ? ' et al.' : '') || 'Unknown',
      relevanceScore: a.analysis?.relevanceScore || 50,
      keyPoints: a.analysis?.keyPoints || [],
      abstract: a.abstract?.substring(0, 500) || ''
    }));

    const prompt = `You are analyzing ${articles.length} academic articles about "${topic}" with a focus on "${focusArea}".

Articles summary:
${JSON.stringify(articleSummaries, null, 2)}

Generate a comprehensive research analysis that:
1. Summarizes the current state of research on this topic from these articles
2. Identifies key findings and themes across the articles
3. Describes common methodologies used
4. Draws conclusions about the state of research
5. Provides recommendations for further research

Respond ONLY with a valid JSON object in this exact format:
{
  "summary": "comprehensive summary paragraph",
  "keyFindings": ["finding 1", "finding 2", "finding 3"],
  "methodology": "description of common methodologies",
  "conclusions": "main conclusions",
  "recommendations": "recommendations for future research"
}`;

    try {
      const completion = await this.zai!.chat.completions.create({
        messages: [
          {
            role: 'assistant',
            content: 'You are an expert academic research synthesizer. Provide comprehensive, well-structured analysis of research topics. Always respond with ONLY valid JSON, no markdown code blocks or additional text.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        thinking: { type: 'disabled' }
      });

      const response = completion.choices[0]?.message?.content || '{}';
      console.log('[AnalysisService] Research analysis response:', response.substring(0, 300));
      
      const parsed = this.parseJsonFromResponse(response);
      
      if (parsed) {
        return {
          sessionId: '',
          summary: typeof parsed.summary === 'string' ? parsed.summary : 'Analysis not available',
          keyFindings: Array.isArray(parsed.keyFindings) ? parsed.keyFindings : ['Could not extract key findings'],
          methodology: typeof parsed.methodology === 'string' ? parsed.methodology : 'Not determined',
          conclusions: typeof parsed.conclusions === 'string' ? parsed.conclusions : 'Not available',
          recommendations: typeof parsed.recommendations === 'string' ? parsed.recommendations : 'Not available',
          articleAnalyses: articles.map(a => a.analysis!).filter(Boolean)
        };
      }
    } catch (error) {
      console.error('[AnalysisService] Research analysis error:', error);
    }

    // Default response if parsing fails
    return {
      sessionId: '',
      summary: 'Unable to generate comprehensive analysis. Please try again with different parameters.',
      keyFindings: ['Analysis generation failed'],
      methodology: 'Not determined',
      conclusions: 'Not available',
      recommendations: 'Please try again with a more specific topic or focus area',
      articleAnalyses: articles.map(a => a.analysis!).filter(Boolean)
    };
  }

  /**
   * Generate a quick summary of an article's relevance
   */
  async quickRelevanceCheck(
    article: ArxivSearchResult,
    focusArea: string
  ): Promise<{ score: number; reason: string }> {
    await this.initialize();

    const prompt = `Rate the relevance of this article to the topic "${focusArea}" on a scale of 0-100.

Article: "${article.title}"
Abstract: ${article.abstract?.substring(0, 300) || 'No abstract'}

Respond ONLY with a valid JSON object:
{
  "score": 75,
  "reason": "brief explanation"
}`;

    try {
      const completion = await this.zai!.chat.completions.create({
        messages: [
          {
            role: 'assistant',
            content: 'You are an academic research assistant. Provide concise relevance assessments. Always respond with ONLY valid JSON.'
          },
          {
            role: 'user',
            content: prompt
          }
        ],
        thinking: { type: 'disabled' }
      });

      const response = completion.choices[0]?.message?.content || '{}';
      const parsed = this.parseJsonFromResponse(response);
      
      if (parsed) {
        return {
          score: typeof parsed.score === 'number' ? parsed.score : 50,
          reason: typeof parsed.reason === 'string' ? parsed.reason : 'Unable to determine relevance'
        };
      }
    } catch (error) {
      console.error('[AnalysisService] Relevance check error:', error);
    }

    return {
      score: 50,
      reason: 'Unable to determine relevance'
    };
  }
}

// Singleton instance
export const analysisService = new AnalysisService();
