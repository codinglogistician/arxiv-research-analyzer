'use client';

import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Search, 
  FileText, 
  Brain, 
  Clock, 
  ExternalLink, 
  Download, 
  Trash2, 
  RefreshCw,
  BookOpen,
  CheckCircle2,
  XCircle,
  Loader2,
  Sparkles,
  Target,
  BarChart3,
  ChevronRight,
  History
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { toast } from 'sonner';

interface Article {
  id: string;
  arxivId: string | null;
  title: string;
  authors: string;
  abstract: string | null;
  pdfUrl: string | null;
  arxivUrl: string | null;
  publishedDate: string | null;
  createdAt: string;
}

interface Analysis {
  id: string;
  summary: string;
  keyFindings: string;
  methodology: string | null;
  conclusions: string | null;
  recommendations: string | null;
}

interface ResearchSession {
  id: string;
  topic: string;
  focusArea: string;
  status: string;
  createdAt: string;
  articles: Article[];
  analysis: Analysis | null;
}

interface SessionListItem {
  id: string;
  topic: string;
  focusArea: string;
  status: string;
  createdAt: string;
  _count: {
    articles: number;
  };
}

export default function HomePage() {
  const [topic, setTopic] = useState('');
  const [focusArea, setFocusArea] = useState('');
  const [maxArticles, setMaxArticles] = useState(5);
  const [isLoading, setIsLoading] = useState(false);
  const [currentSession, setCurrentSession] = useState<ResearchSession | null>(null);
  const [sessions, setSessions] = useState<SessionListItem[]>([]);
  const [activeTab, setActiveTab] = useState('search');

  // Fetch historical sessions
  const fetchSessions = useCallback(async () => {
    try {
      const response = await fetch('/api/sessions?limit=20');
      const data = await response.json();
      if (data.success) {
        setSessions(data.data.sessions);
      }
    } catch (error) {
      console.error('Failed to fetch sessions:', error);
    }
  }, []);

  useEffect(() => {
    fetchSessions();
  }, [fetchSessions]);

  // Poll for session updates
  useEffect(() => {
    if (!currentSession || currentSession.status === 'completed' || currentSession.status === 'error') {
      return;
    }

    const interval = setInterval(async () => {
      try {
        const response = await fetch(`/api/research?sessionId=${currentSession.id}`);
        const data = await response.json();
        if (data.success) {
          setCurrentSession(data.data);
          if (data.data.status === 'completed' || data.data.status === 'error') {
            fetchSessions();
          }
        }
      } catch (error) {
        console.error('Failed to poll session:', error);
      }
    }, 3000);

    return () => clearInterval(interval);
  }, [currentSession, fetchSessions]);

  const startResearch = async () => {
    if (!topic.trim() || !focusArea.trim()) {
      toast.error('Proszę wypełnić temat i kąt analizy');
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/research', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic, focusArea, maxArticles })
      });

      const data = await response.json();
      if (data.success) {
        setCurrentSession({
          id: data.data.sessionId,
          topic,
          focusArea,
          status: 'searching',
          createdAt: new Date().toISOString(),
          articles: [],
          analysis: null
        });
        setActiveTab('results');
        toast.success('Badanie rozpoczęte!');
      } else {
        toast.error(data.error || 'Wystąpił błąd');
      }
    } catch (error) {
      console.error('Research error:', error);
      toast.error('Wystąpił błąd podczas rozpoczynania badania');
    } finally {
      setIsLoading(false);
    }
  };

  const loadSession = async (sessionId: string) => {
    try {
      const response = await fetch(`/api/research?sessionId=${sessionId}`);
      const data = await response.json();
      if (data.success) {
        setCurrentSession(data.data);
        setActiveTab('results');
      }
    } catch (error) {
      console.error('Failed to load session:', error);
      toast.error('Nie udało się załadować sesji');
    }
  };

  const deleteSession = async (sessionId: string) => {
    try {
      const response = await fetch(`/api/sessions?sessionId=${sessionId}`, {
        method: 'DELETE'
      });
      const data = await response.json();
      if (data.success) {
        setSessions(prev => prev.filter(s => s.id !== sessionId));
        if (currentSession?.id === sessionId) {
          setCurrentSession(null);
        }
        toast.success('Sesja usunięta');
      }
    } catch (error) {
      console.error('Failed to delete session:', error);
      toast.error('Nie udało się usunąć sesji');
    }
  };

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { variant: 'default' | 'secondary' | 'destructive' | 'outline'; icon: React.ReactNode; text: string }> = {
      pending: { variant: 'secondary', icon: <Clock className="w-3 h-3" />, text: 'Oczekuje' },
      searching: { variant: 'default', icon: <Search className="w-3 h-3" />, text: 'Wyszukiwanie' },
      analyzing: { variant: 'default', icon: <Brain className="w-3 h-3" />, text: 'Analizowanie' },
      completed: { variant: 'default', icon: <CheckCircle2 className="w-3 h-3" />, text: 'Zakończono' },
      error: { variant: 'destructive', icon: <XCircle className="w-3 h-3" />, text: 'Błąd' }
    };
    const config = variants[status] || variants.pending;
    return (
      <Badge variant={config.variant} className="gap-1">
        {config.icon}
        {config.text}
      </Badge>
    );
  };

  const getProgressValue = (status: string, articlesCount: number) => {
    if (status === 'searching') return 25;
    if (status === 'analyzing') return 50 + (articlesCount * 10);
    if (status === 'completed') return 100;
    if (status === 'error') return 0;
    return 0;
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center gap-3">
            <div className="p-2 bg-primary/10 rounded-lg">
              <BookOpen className="w-6 h-6 text-primary" />
            </div>
            <div>
              <h1 className="text-2xl font-bold">arXiv Research Analyzer</h1>
              <p className="text-sm text-muted-foreground">
                Automatyczne pobieranie i analiza artykułów naukowych
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 container mx-auto px-4 py-6">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="mb-6">
            <TabsTrigger value="search" className="gap-2">
              <Search className="w-4 h-4" />
              Nowe Badanie
            </TabsTrigger>
            <TabsTrigger value="results" className="gap-2" disabled={!currentSession}>
              <FileText className="w-4 h-4" />
              Wyniki
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-2">
              <History className="w-4 h-4" />
              Historia ({sessions.length})
            </TabsTrigger>
          </TabsList>

          {/* Search Tab */}
          <TabsContent value="search">
            <div className="grid gap-6 lg:grid-cols-2">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <Target className="w-5 h-5 text-primary" />
                    Parametry Badania
                  </CardTitle>
                  <CardDescription>
                    Zdefiniuj temat i kąt analizy artykułów z arXiv
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-2">
                    <Label htmlFor="topic">Temat badania</Label>
                    <Input
                      id="topic"
                      placeholder="np. machine learning, quantum computing, neural networks"
                      value={topic}
                      onChange={(e) => setTopic(e.target.value)}
                    />
                    <p className="text-xs text-muted-foreground">
                      Wprowadź temat lub słowa kluczowe do wyszukania na arXiv
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="focusArea">Kąt analizy</Label>
                    <Textarea
                      id="focusArea"
                      placeholder="np. Zanalizuj pod kątem zastosowań w medycynie, skup się na metodach uczenia nadzorowanego..."
                      value={focusArea}
                      onChange={(e) => setFocusArea(e.target.value)}
                      rows={3}
                    />
                    <p className="text-xs text-muted-foreground">
                      Określ aspekt, pod którym artykuły mają być przeanalizowane
                    </p>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="maxArticles">Liczba artykułów do analizy</Label>
                    <Input
                      id="maxArticles"
                      type="number"
                      min={1}
                      max={10}
                      value={maxArticles}
                      onChange={(e) => setMaxArticles(parseInt(e.target.value) || 5)}
                    />
                  </div>

                  <Button 
                    onClick={startResearch} 
                    disabled={isLoading || !topic.trim() || !focusArea.trim()}
                    className="w-full"
                    size="lg"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Rozpoczynanie...
                      </>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4" />
                        Rozpocznij Badanie
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center gap-2">
                    <BarChart3 className="w-5 h-5 text-primary" />
                    Jak to działa?
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-primary/10 rounded-lg shrink-0">
                        <Search className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">1. Wyszukiwanie</h4>
                        <p className="text-sm text-muted-foreground">
                          System przeszukuje arXiv w poszukiwaniu artykułów pasujących do tematu
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-primary/10 rounded-lg shrink-0">
                        <FileText className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">2. Pobieranie</h4>
                        <p className="text-sm text-muted-foreground">
                          Pobierane są szczegóły artykułów: tytuły, autorzy, abstrakty
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-primary/10 rounded-lg shrink-0">
                        <Brain className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">3. Analiza AI</h4>
                        <p className="text-sm text-muted-foreground">
                          Model LLM analizuje każdy artykuł pod zadanym kątem
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <div className="p-2 bg-primary/10 rounded-lg shrink-0">
                        <Target className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <h4 className="font-medium">4. Synteza</h4>
                        <p className="text-sm text-muted-foreground">
                          Generowany jest kompleksowy raport z wnioskami i rekomendacjami
                        </p>
                      </div>
                    </div>
                  </div>

                  <Separator className="my-4" />

                  <div className="p-3 bg-muted rounded-lg">
                    <p className="text-sm text-muted-foreground">
                      <strong>Wskazówka:</strong> Im bardziej precyzyjny kąt analizy, tym bardziej trafne i użyteczne wnioski otrzymasz.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Results Tab */}
          <TabsContent value="results">
            {currentSession ? (
              <div className="space-y-6">
                {/* Status Card */}
                <Card>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{currentSession.topic}</CardTitle>
                      {getStatusBadge(currentSession.status)}
                    </div>
                    <CardDescription>
                      Kąt analizy: {currentSession.focusArea}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    {currentSession.status !== 'completed' && currentSession.status !== 'error' && (
                      <div className="space-y-2">
                        <Progress value={getProgressValue(currentSession.status, currentSession.articles.length)} />
                        <p className="text-sm text-muted-foreground flex items-center gap-2">
                          <Loader2 className="w-3 h-3 animate-spin" />
                          {currentSession.status === 'searching' 
                            ? 'Wyszukiwanie artykułów na arXiv...' 
                            : 'Analizowanie artykułów...'}
                        </p>
                      </div>
                    )}
                  </CardContent>
                </Card>

                {/* Analysis Results */}
                {currentSession.analysis && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <Sparkles className="w-5 h-5 text-primary" />
                        Analiza Badawcza
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-[500px] pr-4">
                        <div className="space-y-6">
                          {/* Summary */}
                          <div>
                            <h3 className="font-semibold text-lg mb-2">Podsumowanie</h3>
                            <div className="prose prose-sm dark:prose-invert max-w-none">
                              <ReactMarkdown>
                                {currentSession.analysis.summary}
                              </ReactMarkdown>
                            </div>
                          </div>

                          <Separator />

                          {/* Key Findings */}
                          <div>
                            <h3 className="font-semibold text-lg mb-3">Kluczowe Wnioski</h3>
                            <div className="space-y-2">
                              {(() => {
                                try {
                                  const findings = JSON.parse(currentSession.analysis.keyFindings);
                                  return findings.map((finding: string, i: number) => (
                                    <div key={i} className="flex items-start gap-2 p-3 bg-muted rounded-lg">
                                      <ChevronRight className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                                      <span>{finding}</span>
                                    </div>
                                  ));
                                } catch {
                                  return <p className="text-muted-foreground">{currentSession.analysis.keyFindings}</p>;
                                }
                              })()}
                            </div>
                          </div>

                          <Separator />

                          {/* Methodology */}
                          {currentSession.analysis.methodology && (
                            <>
                              <div>
                                <h3 className="font-semibold text-lg mb-2">Metodologia</h3>
                                <div className="prose prose-sm dark:prose-invert max-w-none">
                                  <ReactMarkdown>
                                    {currentSession.analysis.methodology}
                                  </ReactMarkdown>
                                </div>
                              </div>
                              <Separator />
                            </>
                          )}

                          {/* Conclusions */}
                          {currentSession.analysis.conclusions && (
                            <>
                              <div>
                                <h3 className="font-semibold text-lg mb-2">Wnioski</h3>
                                <div className="prose prose-sm dark:prose-invert max-w-none">
                                  <ReactMarkdown>
                                    {currentSession.analysis.conclusions}
                                  </ReactMarkdown>
                                </div>
                              </div>
                              <Separator />
                            </>
                          )}

                          {/* Recommendations */}
                          {currentSession.analysis.recommendations && (
                            <div>
                              <h3 className="font-semibold text-lg mb-2">Rekomendacje</h3>
                              <div className="prose prose-sm dark:prose-invert max-w-none">
                                <ReactMarkdown>
                                  {currentSession.analysis.recommendations}
                                </ReactMarkdown>
                              </div>
                            </div>
                          )}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                )}

                {/* Articles List */}
                {currentSession.articles.length > 0 && (
                  <Card>
                    <CardHeader>
                      <CardTitle className="flex items-center gap-2">
                        <FileText className="w-5 h-5 text-primary" />
                        Przeanalizowane Artykuły ({currentSession.articles.length})
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ScrollArea className="h-[400px] pr-4">
                        <div className="space-y-4">
                          {currentSession.articles.map((article, index) => (
                            <div key={article.id} className="p-4 border rounded-lg">
                              <div className="flex items-start justify-between gap-4">
                                <div className="flex-1">
                                  <div className="flex items-center gap-2 mb-1">
                                    <Badge variant="outline">{index + 1}</Badge>
                                    {article.arxivId && (
                                      <Badge variant="secondary">arXiv:{article.arxivId}</Badge>
                                    )}
                                  </div>
                                  <h4 className="font-medium mb-1">{article.title}</h4>
                                  <p className="text-sm text-muted-foreground mb-2">
                                    {article.authors}
                                  </p>
                                  {article.abstract && (
                                    <p className="text-sm text-muted-foreground line-clamp-2">
                                      {article.abstract}
                                    </p>
                                  )}
                                </div>
                                <div className="flex gap-2 shrink-0">
                                  {article.arxivUrl && (
                                    <Button variant="outline" size="sm" asChild>
                                      <a href={article.arxivUrl} target="_blank" rel="noopener noreferrer">
                                        <ExternalLink className="w-4 h-4" />
                                      </a>
                                    </Button>
                                  )}
                                  {article.pdfUrl && (
                                    <Button variant="outline" size="sm" asChild>
                                      <a href={article.pdfUrl} target="_blank" rel="noopener noreferrer">
                                        <Download className="w-4 h-4" />
                                      </a>
                                    </Button>
                                  )}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </ScrollArea>
                    </CardContent>
                  </Card>
                )}
              </div>
            ) : (
              <Card>
                <CardContent className="py-12">
                  <div className="text-center text-muted-foreground">
                    <FileText className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Brak wyników do wyświetlenia</p>
                    <p className="text-sm">Rozpocznij nowe badanie lub załaduj sesję z historii</p>
                  </div>
                </CardContent>
              </Card>
            )}
          </TabsContent>

          {/* History Tab */}
          <TabsContent value="history">
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle className="flex items-center gap-2">
                    <History className="w-5 h-5 text-primary" />
                    Historia Badań
                  </CardTitle>
                  <Button variant="outline" size="sm" onClick={fetchSessions}>
                    <RefreshCw className="w-4 h-4" />
                    Odśwież
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                {sessions.length > 0 ? (
                  <ScrollArea className="h-[600px]">
                    <div className="space-y-3">
                      {sessions.map((session) => (
                        <div 
                          key={session.id} 
                          className="flex items-center justify-between p-4 border rounded-lg hover:bg-muted/50 transition-colors"
                        >
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-1">
                              {getStatusBadge(session.status)}
                              <span className="text-sm text-muted-foreground">
                                {new Date(session.createdAt).toLocaleString('pl-PL')}
                              </span>
                            </div>
                            <h4 className="font-medium">{session.topic}</h4>
                            <p className="text-sm text-muted-foreground">
                              Kąt: {session.focusArea}
                            </p>
                            <p className="text-xs text-muted-foreground mt-1">
                              {session._count.articles} artykułów
                            </p>
                          </div>
                          <div className="flex gap-2">
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => loadSession(session.id)}
                              disabled={session.status === 'pending' || session.status === 'searching' || session.status === 'analyzing'}
                            >
                              <FileText className="w-4 h-4" />
                              Zobacz
                            </Button>
                            <Button 
                              variant="outline" 
                              size="sm"
                              onClick={() => deleteSession(session.id)}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                ) : (
                  <div className="text-center py-12 text-muted-foreground">
                    <History className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Brak historii badań</p>
                    <p className="text-sm">Rozpocznij pierwsze badanie!</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Footer */}
      <footer className="border-t bg-card mt-auto">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between text-sm text-muted-foreground">
            <span>arXiv Research Analyzer</span>
            <span>Powered by AI</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
