import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/sonner";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "arXiv Research Analyzer - AI-Powered Academic Research",
  description: "Automatyczne pobieranie i analiza artykułów naukowych z arXiv z wykorzystaniem AI. Przeszukuj, analizuj i syntetyzuj badania naukowe.",
  keywords: ["arXiv", "AI", "research", "academic", "papers", "analysis", "machine learning", "NLP"],
  authors: [{ name: "Z.ai Team" }],
  icons: {
    icon: "/logo.svg",
  },
  openGraph: {
    title: "arXiv Research Analyzer",
    description: "AI-powered academic research analysis tool",
    type: "website",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        {children}
        <Toaster />
      </body>
    </html>
  );
}
